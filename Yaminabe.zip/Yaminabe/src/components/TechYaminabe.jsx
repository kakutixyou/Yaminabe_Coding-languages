import React, { useState, useMemo, useEffect } from 'react';
import data from '../data/masterData.json';
import aiSelections from '../data/Aiselections.json';

const TechYaminabe = () => {
  const [showAI, setShowAI] = useState(false);
  const [selectedTechs, setSelectedTechs] = useState([]);
  const [showAllTechs, setShowAllTechs] = useState(false);
  const [aiThinking, setAiThinking] = useState(false);
  const [aiComment, setAiComment] = useState('');
  const [currentMetrics, setCurrentMetrics] = useState(null);

  // スタイルシートの注入（アニメーション用）
  useEffect(() => {
    const styleSheet = document.createElement("style");
    styleSheet.textContent = `
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
      @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
      }
      button:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      }
      button:active {
        transform: translateY(0);
      }
    `;
    document.head.appendChild(styleSheet);
    return () => {
      document.head.removeChild(styleSheet);
    };
  }, []);

  // JSONから全ての技術を一つのリストにする
  const allTechList = useMemo(() => {
    if (!data || !data.techStack) return [];
    return Array.isArray(data.techStack) 
      ? data.techStack 
      : Object.values(data.techStack).flat();
  }, []);

  // --- 高度な相性計算アルゴリズム ---
  const evaluateStack = (techs) => {
    if (techs.length < 2) return 0;
    let score = 0;
    let penalty = 0;
    const categories = new Set(techs.map(t => t.category));

    for (let i = 0; i < techs.length; i++) {
      for (let j = i + 1; j < techs.length; j++) {
        const a = techs[i];
        const b = techs[j];
        if (a.compatibility?.includes(b.name) || b.compatibility?.includes(a.name)) score += 20;
        if (a.antiCompatibility?.includes(b.name) || b.antiCompatibility?.includes(a.name)) penalty += 40;
        if (Math.abs((a.era || 2020) - (b.era || 2020)) > 30) penalty += 20;
      }
    }
    if (categories.has('frontend') && categories.has('backend') && categories.has('database')) score += 30;
    
    let chaosScore = 50 + penalty - score;
    return Math.max(0, Math.min(100, chaosScore));
  };

  const chaosLevel = useMemo(() => evaluateStack(selectedTechs), [selectedTechs]);

  // --- 動的メトリクス計算 ---
  const calculatedMetrics = useMemo(() => {
    if (selectedTechs.length === 0) return null;
    
    // カオス度に基づいて動的に計算
    const chaos = chaosLevel;
    
    // 作りやすさ: カオスが高いほど低い (100 - カオス度 - ランダム要素)
    const buildability = Math.max(5, Math.min(100, 100 - chaos - Math.random() * 15));
    
    // 勉強のしやすさ: レガシー技術が多いと下がる、モダン技術が多いと上がる
    const legacyCount = selectedTechs.filter(t => t.isLegacy).length;
    const modernBonus = selectedTechs.some(t => 
      ['TypeScript', 'React', 'Vue.js', 'Python'].some(name => t.name.includes(name))
    ) ? 10 : 0;
    const learnability = Math.max(5, Math.min(100, 90 - chaos - (legacyCount * 15) + modernBonus));
    
    // スペースシャトル破壊数: カオス度と技術数に比例
    const baseShuttles = (chaos / 20) + (selectedTechs.length * 0.2);
    const legacyPenalty = legacyCount * 0.8;
    const antiCompatibilityCount = selectedTechs.reduce((count, tech) => {
      const conflicts = selectedTechs.filter(other => 
        tech.antiCompatibility?.includes(other.name) || other.antiCompatibility?.includes(tech.name)
      );
      return count + conflicts.length;
    }, 0) / 2; // 重複を除く
    
    const shuttlesPerYear = Math.max(0.1, baseShuttles + legacyPenalty + (antiCompatibilityCount * 0.5));
    
    return {
      buildability: Math.round(buildability),
      learnability: Math.round(learnability),
      shuttlesPerYear: parseFloat(shuttlesPerYear.toFixed(1))
    };
  }, [selectedTechs, chaosLevel]);

  // --- 具材の選択・解除 ---
  const toggleTech = (tech) => {
    // 手動で技術を変更したらAIメトリクスをクリア（動的計算に切り替え）
    setCurrentMetrics(null);
    
    if (selectedTechs.find(t => t.name === tech.name)) {
      setSelectedTechs(selectedTechs.filter(t => t.name !== tech.name));
    } else {
      setSelectedTechs([...selectedTechs, tech]);
    }
  };

  // --- ランダム生成 ---
  const createRandomNabe = (count) => {
    let pool = [...allTechList];
    let selected = [];
    for (let i = 0; i < count; i++) {
      if (pool.length === 0) break;
      const randomIndex = Math.floor(Math.random() * pool.length);
      selected.push(pool[randomIndex]);
      pool.splice(randomIndex, 1);
    }
    setSelectedTechs(selected);
    setAiComment('');
    setCurrentMetrics(null);
  };

  // --- AI選択ロジック（JSON駆動） ---
  const selectAiChoice = (aiName, modeKey) => {
    setAiThinking(true);
    setAiComment('');

    // AIが考えている演出
    setTimeout(() => {
      const aiData = aiSelections.aiSelections[aiName];
      const mode = aiData.modes[modeKey];
      
      // 文字列の一致で技術を検索（曖昧一致）
      const selected = allTechList.filter(tech =>
        mode.techs.some(name =>
          tech.name.includes(name) || name.includes(tech.name)
        )
      );

      setSelectedTechs(selected);
      setAiComment(mode.comment);
      // AI選択時は元のメトリクスを表示（currentMetricsに保存）
      setCurrentMetrics(mode.metrics);
      setAiThinking(false);
    }, 1000);
  };

  const analyzeCurrentStack = () => {
    if (selectedTechs.length === 0) {
      setAiComment('技術が選択されていません。何か選んでから分析ボタンを押してください。');
      return;
    }

    setAiThinking(true);
    setTimeout(() => {
      let analysis = '🤔 **AI による技術スタック分析**\n\n';
      
      const chaos = chaosLevel;
      const techNames = selectedTechs.map(t => t.name);
      
      // カオス度評価
      if (chaos >= 80) {
        analysis += '**総合評価: 🔥 危険水域 🔥**\n';
        analysis += 'このスタックは技術的負債の塊です。実装を始める前に、チーム全体でカウンセリングを受けることをお勧めします。\n\n';
      } else if (chaos >= 60) {
        analysis += '**総合評価: ⚠️ 挑戦的 ⚠️**\n';
        analysis += '実装は可能ですが、統合で大きな問題に直面するでしょう。優秀なシニアエンジニアが3人は必要です。\n\n';
      } else if (chaos >= 40) {
        analysis += '**総合評価: 🤝 実用的 🤝**\n';
        analysis += '標準的な構成です。ドキュメントを読めば実装できます。特に面白みはありませんが、それが良いことです。\n\n';
      } else {
        analysis += '**総合評価: ✨ 優秀 ✨**\n';
        analysis += '非常にバランスの取れた構成です。教科書に載せても良いレベル。ただし、もう少し冒険してみても良いかもしれません。\n\n';
      }

      setAiComment(analysis);
      setAiThinking(false);
    }, 1500);
  };

  const getPunchline = () => {
    if (!data.humorTemplates) return "「この組み合わせは、未知の領域です。」";
    
    const names = selectedTechs.map(t => t.name);
    const template = data.humorTemplates.find(h => {
      if (h.requires && h.requires.every(req => names.some(n => n.includes(req)))) return true;
      if (h.minChaos !== undefined && chaosLevel >= h.minChaos && (h.maxChaos === undefined || chaosLevel <= h.maxChaos)) return true;
      return false;
    });
    return template ? template.text : "「この組み合わせは、未知の領域です。」";
  };

  // メトリクス表示コンポーネント
  const MetricsDisplay = ({ metrics }) => {
    if (!metrics) return null;
    
    return (
      <div style={styles.metricsBox}>
        <h4 style={styles.metricsTitle}>📊 技術スタック評価指標</h4>
        <div style={styles.metricsGrid}>
          <div style={styles.metricItem}>
            <div style={styles.metricLabel}>🛠️ 作りやすさ</div>
            <div style={styles.metricBar}>
              <div 
                style={{
                  ...styles.metricFill,
                  width: `${metrics.buildability}%`,
                  backgroundColor: metrics.buildability >= 70 ? '#10b981' : metrics.buildability >= 40 ? '#f59e0b' : '#ef4444'
                }}
              ></div>
            </div>
            <div style={styles.metricValue}>{metrics.buildability}/100</div>
          </div>
          
          <div style={styles.metricItem}>
            <div style={styles.metricLabel}>📚 勉強のしやすさ</div>
            <div style={styles.metricBar}>
              <div 
                style={{
                  ...styles.metricFill,
                  width: `${metrics.learnability}%`,
                  backgroundColor: metrics.learnability >= 70 ? '#10b981' : metrics.learnability >= 40 ? '#f59e0b' : '#ef4444'
                }}
              ></div>
            </div>
            <div style={styles.metricValue}>{metrics.learnability}/100</div>
          </div>
          
          <div style={styles.metricItem}>
            <div style={styles.metricLabel}>🚀 仕方なくスペースシャトルのように一部のデータを削除する/年</div>
            <div style={styles.shuttleDisplay}>
              <span style={{
                fontSize: '2em',
                fontWeight: 'bold',
                color: metrics.shuttlesPerYear >= 5 ? '#ef4444' : metrics.shuttlesPerYear >= 2 ? '#f59e0b' : '#10b981'
              }}>
                {metrics.shuttlesPerYear.toFixed(1)}
              </span>
              <span style={{ fontSize: '0.9em', color: '#666', marginLeft: '5px' }}>回</span>
            </div>
            <div style={styles.shuttleDesc}>
              {metrics.shuttlesPerYear >= 10 ? '🔥 NASA全滅レベル' :
               metrics.shuttlesPerYear >= 5 ? '💥 大惨事' :
               metrics.shuttlesPerYear >= 2 ? '⚠️ 重大事故' :
               metrics.shuttlesPerYear >= 1 ? '😰 小規模事故' :
               '✨ 安全運航'}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h1 style={styles.title}>🍲 Tech Yaminabe</h1>
        <p style={styles.tagline}>技術と欲望のカオスジェネレーター</p>
        
        {/* 現在の具材数表示 */}
        <div style={styles.counterBox}>
          現在の具材数: <span style={styles.counterNum}>{selectedTechs.length}</span> 種類
        </div>

        {/* AI Selection Toggle */}
        <div style={styles.aiToggleSection}>
          <button
            onClick={() => setShowAI(!showAI)}
            style={styles.subBtn}
          >
            {showAI ? '▲ AI選択メニューを閉じる' : '▼ AI (Claude/ChatGPT/Gemini/おじさん/Aider) に選ばせる'}
          </button>
        </div>

        {showAI && (
          <div style={styles.aiContainer}>
            {/* 各AIのセクションを動的に生成 */}
            {Object.entries(aiSelections.aiSelections).map(([aiKey, aiData]) => (
              <div key={aiKey} style={{
                ...styles.aiSection,
                borderColor: aiData.color,
                background: `${aiData.color}08`
              }}>
                <h3 style={styles.sectionTitle}>
                  {aiData.emoji} {aiData.name} の選択
                </h3>
                <div style={styles.aiGrid}>
                  {Object.entries(aiData.modes).map(([modeKey, mode]) => (
                    <button
                      key={modeKey}
                      onClick={() => selectAiChoice(aiKey, modeKey)}
                      style={styles.aiBtn}
                      disabled={aiThinking}
                    >
                      <div style={styles.aiBtnEmoji}>{mode.emoji}</div>
                      <div style={styles.aiBtnName}>{mode.name}</div>
                      <div style={styles.aiBtnDesc}>{mode.description}</div>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        <div style={styles.divider}></div>

        <div style={styles.modeButtons}>
          <button onClick={() => setShowAllTechs(!showAllTechs)} style={styles.subBtn}>
            {showAllTechs ? '▲ リストを閉じる' : '▼ 自分で具材を選ぶ'}
          </button>
          <button onClick={() => createRandomNabe(6)} style={styles.mainBtn}>
            🎲 おまかせで作る (6種)
          </button>
        </div>

        {/* 手動選択リスト */}
        {showAllTechs && (
          <div style={styles.techSelectionList}>
            {allTechList.map((tech, i) => {
              const isSelected = selectedTechs.find(t => t.name === tech.name);
              return (
                <button 
                  key={i} 
                  onClick={() => toggleTech(tech)}
                  style={{
                    ...styles.techChip,
                    backgroundColor: isSelected ? '#667eea' : '#f0f0f0',
                    color: isSelected ? '#fff' : '#333',
                    border: isSelected ? '2px solid #764ba2' : '1px solid #ccc'
                  }}
                >
                  {tech.name}
                </button>
              );
            })}
          </div>
        )}

        {selectedTechs.length > 0 && (
          <div style={styles.resultArea}>
            <div style={styles.chaosHeader}>
              <div>
                <span style={styles.chaosLabel}>カオス度: </span>
                <span style={{
                  ...styles.chaosValue, 
                  color: chaosLevel > 70 ? '#ff4d4d' : chaosLevel > 40 ? '#ffaa00' : '#4caf50'
                }}>
                  {chaosLevel}%
                </span>
              </div>
              <div style={styles.actionButtons}>
                <button onClick={analyzeCurrentStack} style={styles.analyzeBtn} disabled={aiThinking}>
                  {aiThinking ? '🤔 分析中...' : '🧠 AI 考察'}
                </button>
                <button onClick={() => {
                  setSelectedTechs([]);
                  setAiComment('');
                  setCurrentMetrics(null);
                }} style={styles.clearBtn}>
                  🗑️ 鍋を空にする
                </button>
              </div>
            </div>

            <div style={styles.grid}>
              {selectedTechs.map((t, i) => (
                <div key={i} style={styles.techItem}>
                  <div style={styles.techName}>{t.name}</div>
                  <div style={styles.techDesc}>{t.specialty}</div>
                  {t.isLegacy && <div style={styles.legacyBadge}>LEGACY</div>}
                </div>
              ))}
            </div>

            {/* メトリクス表示 */}
            {(currentMetrics || calculatedMetrics) && (
              <MetricsDisplay metrics={currentMetrics || calculatedMetrics} />
            )}

            {aiComment && (
              <div style={styles.aiCommentBox}>
                <h4 style={styles.commentTitle}>💭 AI のコメント</h4>
                <pre style={styles.commentText}>{aiComment}</pre>
              </div>
            )}

            <div style={styles.humorBox}>
              <p style={styles.humorText}>{getPunchline()}</p>
            </div>
          </div>
        )}

        {aiThinking && (
          <div style={styles.thinkingOverlay}>
            <div style={styles.thinkingBox}>
              <div style={styles.spinner}></div>
              <p>AI が技術選定の言い訳を考えています...</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  container: { 
    minHeight: '100vh', 
    display: 'flex', 
    justifyContent: 'center', 
    padding: '40px 20px', 
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
  },
  card: { 
    background: 'white', 
    padding: '40px', 
    borderRadius: '20px', 
    maxWidth: '1200px', 
    width: '100%', 
    boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
    position: 'relative'
  },
  title: { 
    textAlign: 'center', 
    marginBottom: '10px',
    fontSize: '2.5em',
    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    WebkitBackgroundClip: 'text',
    WebkitTextFillColor: 'transparent',
    fontWeight: '800'
  },
  tagline: {
    textAlign: 'center',
    color: '#666',
    fontStyle: 'italic',
    marginBottom: '30px'
  },
  counterBox: { 
    textAlign: 'center', 
    fontSize: '1.2rem', 
    padding: '15px', 
    background: '#f8f9fa', 
    borderRadius: '10px', 
    marginBottom: '30px', 
    border: '2px solid #667eea',
    fontWeight: 'bold',
    color: '#555'
  },
  counterNum: { 
    fontSize: '2rem', 
    fontWeight: '900', 
    color: '#667eea',
    marginLeft: '10px',
    marginRight: '5px'
  },
  aiToggleSection: {
    marginBottom: '15px'
  },
  aiContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
    marginBottom: '30px',
    animation: 'fadeIn 0.3s ease'
  },
  aiSection: {
    padding: '20px',
    borderRadius: '15px',
    border: '2px solid'
  },
  sectionTitle: {
    marginTop: 0,
    marginBottom: '15px',
    color: '#444',
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    fontSize: '1.1em',
    fontWeight: 'bold'
  },
  aiGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
    gap: '12px'
  },
  aiBtn: {
    padding: '15px',
    background: 'white',
    border: '2px solid #e1e4e8',
    borderRadius: '12px',
    cursor: 'pointer',
    transition: 'all 0.2s',
    textAlign: 'center',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    height: '100%'
  },
  aiBtnEmoji: {
    fontSize: '2em',
    marginBottom: '8px'
  },
  aiBtnName: {
    fontWeight: 'bold',
    fontSize: '0.9em',
    color: '#333',
    marginBottom: '5px'
  },
  aiBtnDesc: {
    fontSize: '0.75em',
    color: '#666'
  },
  divider: {
    height: '2px',
    background: 'linear-gradient(to right, transparent, #e0e0e0, transparent)',
    margin: '30px 0'
  },
  modeButtons: { 
    display: 'flex', 
    gap: '10px', 
    marginBottom: '20px',
    flexWrap: 'wrap'
  },
  mainBtn: { 
    flex: 2, 
    padding: '15px', 
    background: 'linear-gradient(to right, #667eea, #764ba2)', 
    color: 'white', 
    border: 'none', 
    borderRadius: '10px', 
    cursor: 'pointer', 
    fontWeight: 'bold',
    fontSize: '1.1em',
    transition: 'transform 0.2s',
    minWidth: '200px'
  },
  subBtn: { 
    flex: 1, 
    padding: '15px', 
    background: '#10b981', 
    color: 'white',
    border: 'none', 
    borderRadius: '10px', 
    cursor: 'pointer',
    fontWeight: 'bold',
    minWidth: '200px'
  },
  techSelectionList: { 
    display: 'flex', 
    flexWrap: 'wrap', 
    gap: '8px', 
    padding: '20px', 
    background: '#f8f9fa', 
    border: '2px solid #ddd', 
    borderRadius: '10px', 
    marginBottom: '20px', 
    maxHeight: '300px', 
    overflowY: 'auto' 
  },
  techChip: { 
    padding: '8px 16px', 
    borderRadius: '20px', 
    fontSize: '0.9rem', 
    cursor: 'pointer', 
    transition: 'all 0.2s',
    fontWeight: '500'
  },
  resultArea: { 
    marginTop: '30px',
    padding: '20px',
    background: '#f8f9fa',
    borderRadius: '15px',
    animation: 'fadeIn 0.5s ease'
  },
  chaosHeader: { 
    display: 'flex', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    marginBottom: '20px',
    flexWrap: 'wrap',
    gap: '10px'
  },
  chaosLabel: {
    color: '#2d3748',
    fontSize: '1.2rem',
    fontWeight: 'bold'
  },
  chaosValue: { 
    fontSize: '2em', 
    fontWeight: 'bold',
    marginLeft: '10px'
  },
  actionButtons: {
    display: 'flex',
    gap: '10px',
    flexWrap: 'wrap'
  },
  analyzeBtn: {
    padding: '10px 20px',
    background: '#667eea',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontWeight: 'bold',
    fontSize: '0.95em',
    transition: 'all 0.2s',
    boxShadow: '0 2px 5px rgba(0,0,0,0.2)'
  },
  clearBtn: { 
    padding: '10px 20px', 
    fontSize: '0.95em', 
    background: '#dc3545', 
    color: '#fff', 
    border: 'none', 
    borderRadius: '8px', 
    cursor: 'pointer', 
    fontWeight: 'bold',
    transition: 'all 0.2s'
  },
  grid: { 
    display: 'grid', 
    gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', 
    gap: '12px',
    marginBottom: '20px'
  },
  techItem: { 
    padding: '15px', 
    border: '1px solid #e1e4e8', 
    borderRadius: '10px', 
    background: 'white',
    position: 'relative',
    transition: 'all 0.2s',
    boxShadow: '0 2px 4px rgba(0,0,0,0.05)'
  },
  techName: { 
    fontWeight: 'bold', 
    color: '#2d3748', 
    marginBottom: '8px',
    fontSize: '1.1em'
  },
  techDesc: { 
    fontSize: '0.85rem', 
    color: '#718096',
    lineHeight: '1.4'
  },
  legacyBadge: {
    position: 'absolute',
    top: '8px',
    right: '8px',
    background: '#e53e3e',
    color: 'white',
    padding: '2px 6px',
    borderRadius: '4px',
    fontSize: '0.65em',
    fontWeight: 'bold',
    letterSpacing: '0.5px'
  },
  metricsBox: {
    marginTop: '20px',
    marginBottom: '20px',
    padding: '25px',
    background: 'white',
    borderRadius: '12px',
    border: '2px solid #10b981',
    boxShadow: '0 4px 12px rgba(16, 185, 129, 0.1)'
  },
  metricsTitle: {
    marginTop: 0,
    marginBottom: '20px',
    color: '#10b981',
    fontSize: '1.2em',
    fontWeight: 'bold',
    textAlign: 'center'
  },
  metricsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '20px'
  },
  metricItem: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  metricLabel: {
    fontSize: '0.95em',
    fontWeight: '600',
    color: '#2d3748'
  },
  metricBar: {
    width: '100%',
    height: '24px',
    background: '#e5e7eb',
    borderRadius: '12px',
    overflow: 'hidden',
    position: 'relative'
  },
  metricFill: {
    height: '100%',
    transition: 'width 0.5s ease',
    borderRadius: '12px'
  },
  metricValue: {
    fontSize: '0.9em',
    color: '#6b7280',
    textAlign: 'right',
    fontWeight: 'bold'
  },
  shuttleDisplay: {
    textAlign: 'center',
    padding: '10px',
    background: '#f9fafb',
    borderRadius: '8px'
  },
  shuttleDesc: {
    textAlign: 'center',
    fontSize: '0.85em',
    fontWeight: '600',
    marginTop: '5px'
  },
  aiCommentBox: {
    marginTop: '20px',
    padding: '25px',
    background: 'white',
    borderRadius: '12px',
    borderLeft: '5px solid #667eea',
    boxShadow: '0 4px 12px rgba(102, 126, 234, 0.1)'
  },
  commentTitle: {
    marginTop: 0,
    marginBottom: '10px',
    color: '#667eea',
    fontSize: '1.1em',
    fontWeight: 'bold'
  },
  commentText: {
    whiteSpace: 'pre-wrap',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    fontSize: '0.95em',
    lineHeight: '1.7',
    color: '#2d3748',
    margin: 0
  },
  humorBox: { 
    marginTop: '20px', 
    padding: '15px 20px', 
    background: '#fff3cd', 
    borderLeft: '5px solid #ffc107', 
    borderRadius: '8px',
    fontStyle: 'italic'
  },
  humorText: {
    margin: 0,
    color: '#856404',
    lineHeight: '1.6',
    fontWeight: '500'
  },
  thinkingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'rgba(255, 255, 255, 0.9)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: '20px',
    zIndex: 1000,
    backdropFilter: 'blur(2px)'
  },
  thinkingBox: {
    textAlign: 'center',
    background: 'white',
    padding: '30px',
    borderRadius: '20px',
    boxShadow: '0 10px 30px rgba(0,0,0,0.1)'
  },
  spinner: {
    width: '50px',
    height: '50px',
    border: '4px solid #f3f3f3',
    borderTop: '4px solid #667eea',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite',
    margin: '0 auto 20px'
  }
};

export default TechYaminabe;