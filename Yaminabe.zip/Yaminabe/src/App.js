import React from 'react';
import TechYaminabe from './components/TechYaminabe';
import './App.css'; // 全体の雰囲気作り用

function App() {
  return (
    <div className="App">
      {/* 湯気のような背景アニメーションや、全体のコンテナ */}
      <main>
        <TechYaminabe />
      </main>
      
      <footer style={{ textAlign: 'center', padding: '20px', color: 'white', opacity: 0.7 }}>
        <p>© 2026 闇鍋プログラミング保存会 - 胃もたれにご注意ください</p>
      </footer>
    </div>
  );
}

export default App;